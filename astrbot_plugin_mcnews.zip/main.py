import asyncio
from typing import Dict

import astrbot.api.star as star
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.event import MessageEventResult
from astrbot.api import logger, AstrBotConfig
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from .mcnews.models import MCVersion
from .mcnews.fetcher import MCNewsFetcher
from .mcnews.formatter import MCNewsFormatter
from .mcnews.storage import DataStorage


class Main(star.Star):

    def __init__(self, context: star.Context, config: AstrBotConfig) -> None:
        super().__init__(context)
        self.context = context
        self.config = config
        self.scheduler = AsyncIOScheduler()
        self.storage = DataStorage()
        self.last_service_status: Dict[str, bool] = {}
        self._init_scheduler()

    def _init_scheduler(self):
        self.scheduler.add_job(
            self._check_versions,
            "interval",
            minutes=self.config.get("version_check_interval", 15),
            id="check_versions",
            misfire_grace_time=60
        )
        self.scheduler.add_job(
            self._check_service_status,
            "interval",
            minutes=self.config.get("service_check_interval", 5),
            id="check_service_status",
            misfire_grace_time=60
        )
        self.scheduler.start()
        logger.info("MCNews: Scheduler started")

    async def initialize(self):
        logger.info("MCNews: Plugin activated, starting initial check...")
        await asyncio.sleep(10)
        asyncio.create_task(self._init_service_status())
        asyncio.create_task(self._check_versions())

    async def terminate(self):
        self.scheduler.shutdown()
        self.storage.save()
        logger.info("MCNews: Plugin terminated")

    def _get_whitelist(self):
        return self.config.get("whitelist", [])

    def _add_to_whitelist(self, session: str) -> bool:
        whitelist = self._get_whitelist()
        if session in whitelist:
            return False
        whitelist.append(session)
        self.config["whitelist"] = whitelist
        self.config.save_config()
        return True

    def _remove_from_whitelist(self, session: str) -> bool:
        whitelist = self._get_whitelist()
        if session not in whitelist:
            return False
        whitelist.remove(session)
        self.config["whitelist"] = whitelist
        self.config.save_config()
        return True

    async def _send_to_whitelist(self, message: str):
        whitelist = self._get_whitelist()
        if not whitelist:
            return

        for session in whitelist:
            try:
                await self.context.send_message(
                    session,
                    MessageEventResult().message(message)
                )
            except Exception as e:
                logger.error(f"MCNews: Failed to send message to {session}: {e}")

    async def _init_service_status(self):
        services = await MCNewsFetcher.fetch_all_services_status()
        for service in services:
            self.last_service_status[service.name] = service.online
        logger.info(f"MCNews: Initialized service status tracking for {len(services)} services")

    async def _check_service_status(self):
        if not self.config.get("notify_service_status", True):
            return

        services = await MCNewsFetcher.fetch_all_services_status()
        if not services:
            return

        for service in services:
            last_status = self.last_service_status.get(service.name)
            
            if last_status is None:
                self.last_service_status[service.name] = service.online
                continue

            if last_status != service.online:
                self.last_service_status[service.name] = service.online
                
                message = MCNewsFormatter.format_service_change(
                    service.name,
                    service.online,
                    service.latency,
                    service.error_message
                )
                
                await self._send_to_whitelist(message)
                await asyncio.sleep(1)

    async def _check_versions(self):
        if not self.config.get("notify_versions", True):
            return

        version_data = await MCNewsFetcher.fetch_versions()
        if not version_data:
            return

        versions = version_data.get("versions", [])
        notified = self.storage.get_notified_versions()
        notify_snapshot = self.config.get("notify_snapshot", True)

        new_version = None

        for version in versions[:20]:
            version_id = version.get("id", "")
            version_type = version.get("type", "")

            if version_id in notified:
                continue

            if version_type == "snapshot" and not notify_snapshot:
                self.storage.add_notified_version(version_id)
                continue

            if version_type in ["release", "snapshot"]:
                mc_version = MCVersion(
                    id=version_id,
                    type=version_type,
                    url=version.get("url", ""),
                    time=version.get("time", ""),
                    release_time=version.get("releaseTime", "")
                )
                self.storage.add_notified_version(version_id)
                new_version = mc_version
                break

        self.storage.save()

        if new_version:
            content = await MCNewsFetcher.fetch_article_content(new_version.article_url)
            new_version.content = content
            message = MCNewsFormatter.format_version_push(new_version)
            await self._send_to_whitelist(message)
            logger.info(f"MCNews: Pushed version: {new_version.id}")

    @filter.command_group("mcnews")
    def mcnews(self):
        pass

    @mcnews.command("status")
    async def cmd_status(self, event: AstrMessageEvent):
        yield event.plain_result("Checking Mojang service status...")
        services = await MCNewsFetcher.fetch_all_services_status()
        message = MCNewsFormatter.format_services_status_all(services)
        yield event.plain_result(message)

    @mcnews.command("latest")
    async def cmd_latest(self, event: AstrMessageEvent):
        version_data = await MCNewsFetcher.fetch_versions()

        if not version_data:
            yield event.plain_result("Failed to get version info.")
            return

        latest = version_data.get("latest", {})
        versions = version_data.get("versions", [])

        message = MCNewsFormatter.format_latest_versions(latest, versions)
        yield event.plain_result(message)

    @mcnews.command("add")
    async def cmd_add_whitelist(self, event: AstrMessageEvent):
        session = event.unified_msg_origin

        if self._add_to_whitelist(session):
            yield event.plain_result(f"Added to whitelist.\nSession: {session}")
        else:
            yield event.plain_result(f"Already in whitelist.\nSession: {session}")

    @mcnews.command("remove")
    async def cmd_remove_whitelist(self, event: AstrMessageEvent):
        session = event.unified_msg_origin

        if self._remove_from_whitelist(session):
            yield event.plain_result(f"Removed from whitelist.\nSession: {session}")
        else:
            yield event.plain_result("Not in whitelist.")

    @mcnews.command("list")
    async def cmd_list_whitelist(self, event: AstrMessageEvent):
        whitelist = self._get_whitelist()
        message = MCNewsFormatter.format_whitelist(whitelist)
        yield event.plain_result(message)

    @mcnews.command("help")
    async def cmd_help(self, event: AstrMessageEvent):
        message = MCNewsFormatter.format_help()
        yield event.plain_result(message)

